google.maps.__gjsload__('search_impl', function(_) {
    var cAb = function(a, b) {
            _.dj(a.Gg, 1, b)
        },
        dAb = function(a, b) {
            _.dj(a.Gg, 3, b)
        },
        fAb = function(a) {
            if (_.pn[15]) {
                var b = a.Ml;
                const c = a.Ml = a.getMap();
                b && a.Eg && (a.Hg ? (b = b.__gm.gk, b.set(b.get().Vn(a.Eg))) : a.Eg && _.N_a(a.Eg, b) && ((a.Fg || []).forEach(_.Kk), a.Fg = null));
                if (c) {
                    b = new _.Zw;
                    const d = a.get("layerId").split("|");
                    b.layerId = d[0];
                    for (let e = 1; e < d.length; ++e) {
                        const [f, ...g] = d[e].split(":");
                        b.parameters[f] = g.join(":")
                    }
                    a.get("spotlightDescription") && (b.spotlightDescription = new _.dw(a.get("spotlightDescription")));
                    a.get("paintExperimentIds") &&
                        (b.paintExperimentIds = a.get("paintExperimentIds").slice(0));
                    a.get("styler") && (b.styler = new _.$v(a.get("styler")));
                    a.get("roadmapStyler") && (b.roadmapStyler = new _.$v(a.get("roadmapStyler")));
                    a.get("travelMapRequest") && (b.travelMapRequest = new _.Hqa(a.get("travelMapRequest")));
                    a.get("mapsApiLayer") && (b.mapsApiLayer = new _.ew(a.get("mapsApiLayer")));
                    a.get("mapFeatures") && (b.mapFeatures = a.get("mapFeatures"));
                    a.get("clickableCities") && (b.clickableCities = a.get("clickableCities"));
                    a.get("searchPipeMetadata") &&
                        (b.searchPipeMetadata = new _.Tx(a.get("searchPipeMetadata")));
                    a.get("gmmContextPipeMetadata") && (b.gmmContextPipeMetadata = new _.Coa(a.get("gmmContextPipeMetadata")));
                    a.get("overlayLayer") && (b.overlayLayer = new _.fw(a.get("overlayLayer")));
                    a.get("caseExperimentIds") && (b.caseExperimentIds = a.get("caseExperimentIds").slice(0));
                    a.get("boostMapExperimentIds") && (b.boostMapExperimentIds = a.get("boostMapExperimentIds").slice(0));
                    a.get("airQualityPipeMetadata") && (b.airQualityPipeMetadata = new _.oqa(a.get("airQualityPipeMetadata")));
                    a.get("directionsPipeParameters") && (b.directionsPipeParameters = new _.mqa(a.get("directionsPipeParameters")));
                    a.get("clientSignalPipeMetadata") && (b.clientSignalPipeMetadata = new _.joa(a.get("clientSignalPipeMetadata")));
                    b.darkLaunch = !!a.get("darkLaunch");
                    a.Eg = b;
                    a.Hg = a.get("renderOnBaseMap");
                    a.Hg ? (a = c.__gm.gk, a.set(_.ur(a.get(), b))) : eAb(a, c, b);
                    _.El(c, "Lg");
                    _.M(c, 148282)
                }
            }
        },
        eAb = function(a, b, c) {
            var d = new gAb;
            d = _.CG(d);
            c.Dr = d.load.bind(d);
            c.clickable = a.get("clickable") !== !1;
            _.l_a(c, _.kQ(b));
            b = [];
            b.push(_.Ik(c,
                "click", hAb.bind(null, a)));
            for (const e of ["mouseover", "mouseout", "mousemove"]) b.push(_.Ik(c, e, iAb.bind(null, a, e)));
            b.push(_.Ik(a, "clickable_changed", () => {
                a.Eg.clickable = a.get("clickable") !== !1
            }));
            a.Fg = b
        },
        hAb = function(a, b, c, d, e) {
            let f = null;
            if (e && (f = {
                    status: e.getStatus()
                }, e.getStatus() === 0)) {
                f.location = _.Y(e.Gg, 2) ? new _.uk(_.$s(_.J(e.Gg, 2, _.ft).Gg, 1), _.$s(_.J(e.Gg, 2, _.ft).Gg, 2)) : null;
                const g = {};
                f.fields = g;
                const h = _.Hi(e.Gg, 3);
                for (let k = 0; k < h; ++k) {
                    const m = _.er(e.Gg, 3, _.uQ, k);
                    g[m.getKey()] = m.getValue()
                }
            }
            _.Uk(a,
                "click", b, c, d, f)
        },
        iAb = function(a, b, c, d, e, f, g) {
            let h = null;
            f && (h = {
                title: f[1].title,
                snippet: f[1].snippet
            });
            _.Uk(a, b, c, d, e, h, g)
        },
        jAb = class {},
        kAb = class extends _.V {
            constructor() {
                super()
            }
            fj() {
                return _.L(this.Gg, 2)
            }
        },
        lAb = [_.N, , , _.$o, _.C0a];
    var mAb = class extends _.V {
        constructor(a) {
            super(a)
        }
        getStatus() {
            return _.H(this.Gg, 1, -1)
        }
        getLocation() {
            return _.Xi(this.Gg, 2, _.ft)
        }
    };
    var gAb = class {
        constructor() {
            var a = _.wo,
                b = _.vo;
            this.Eg = _.ej;
            this.fetch = _.rx.bind(jAb, a, _.ny + "/maps/api/js/LayersService.GetFeature", b)
        }
        load(a, b) {
            function c(e) {
                b(new mAb(e))
            }
            const d = new kAb;
            cAb(d, a.layerId.split("|")[0]);
            _.dj(d.Gg, 2, a.featureId);
            dAb(d, this.Eg.Eg().Eg());
            for (const e in a.parameters) {
                const f = _.$i(d.Gg, 4, _.uQ);
                _.dj(f.Gg, 1, e);
                _.dj(f.Gg, 2, a.parameters[e])
            }
            a = _.Bn(d, lAb);
            this.fetch(a, c, c);
            return a
        }
        cancel() {
            throw Error("Not implemented");
        }
    };
    var nAb = class {
        constructor() {
            this.BG = fAb
        }
    };
    _.Aj("search_impl", new nAb);
});